-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7a504.p.ssafy.io    Database: a504
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `contents` varchar(200) NOT NULL,
  `is_deleted` bit(1) NOT NULL,
  `parent_id` int DEFAULT '0',
  `study_id` int NOT NULL,
  `member_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgool88mcf1x0jon5s534a28ag` (`parent_id`),
  KEY `FKcqc53u8w8gfplv2nijq1k7bi5` (`study_id`),
  KEY `FKbu0nxcd71x327o77d8n8a4ffn` (`member_id`),
  CONSTRAINT `FKbu0nxcd71x327o77d8n8a4ffn` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`),
  CONSTRAINT `FKcqc53u8w8gfplv2nijq1k7bi5` FOREIGN KEY (`study_id`) REFERENCES `studies` (`id`),
  CONSTRAINT `FKgool88mcf1x0jon5s534a28ag` FOREIGN KEY (`parent_id`) REFERENCES `inquiries` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiries`
--

LOCK TABLES `inquiries` WRITE;
/*!40000 ALTER TABLE `inquiries` DISABLE KEYS */;
INSERT INTO `inquiries` VALUES (1,'2022-08-18 14:21:13.747925','2022-08-18 14:21:13.747925','jkgjk',_binary '\0',NULL,2,6),(2,'2022-08-18 14:21:45.256956','2022-08-18 14:21:45.256956','dgd',_binary '\0',NULL,5,6),(3,'2022-08-18 14:21:46.522583','2022-08-18 14:21:46.522583','gyfgh',_binary '\0',2,5,6),(4,'2022-08-18 14:23:28.888703','2022-08-18 14:23:28.888703','dddd',_binary '\0',NULL,5,6),(5,'2022-08-18 14:24:42.417261','2022-08-18 15:03:26.006990','adsfsㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎㅎ',_binary '\0',NULL,7,6),(6,'2022-08-18 14:24:43.595864','2022-08-18 14:24:43.595864','dfg',_binary '\0',5,7,6),(7,'2022-08-18 15:03:38.020792','2022-08-18 15:05:06.246994','아ㅓㅁㅇㄹㅇㄹㅋㅎ',_binary '\0',5,7,6),(8,'2022-08-18 15:16:14.634363','2022-08-18 15:16:16.848710','ㄴㄴㄴ',_binary '',NULL,7,6),(9,'2022-08-18 15:16:18.937261','2022-08-18 15:16:18.937261','ㅇㅇㄹㄴ',_binary '\0',NULL,7,6),(10,'2022-08-18 15:20:05.530622','2022-08-18 15:20:05.530622','ㅇㄻㅎㄹ',_binary '\0',9,7,6),(11,'2022-08-18 15:51:59.248872','2022-08-18 15:51:59.248872','주 3회 2시간씩은 조금 힘들 것 같은데 시간 조정해주실 수 있으실까요?ㅜㅠ ',_binary '\0',NULL,9,7),(12,'2022-08-18 15:52:50.879629','2022-08-18 15:52:50.879629','어떤 부서 희망하시는지 여쭤봐도 될까요?',_binary '\0',NULL,9,6),(13,'2022-08-18 15:53:10.776499','2022-08-18 15:53:10.776499','네고는 힘들 것 같네요... 죄송합니다ㅎ',_binary '\0',11,9,4),(14,'2022-08-18 15:53:34.031497','2022-08-18 15:53:34.031497','백엔드 개발이면 다 OK입니다!',_binary '\0',12,9,4),(15,'2022-08-18 16:11:43.271375','2022-08-18 16:11:43.271375','앗 주2회 2시간씩이면 할 수 있을 것 같은데.. 혹시 변경된다면 다시 댓글 남겨주세요!',_binary '\0',11,9,7),(16,'2022-08-18 17:25:12.141677','2022-08-18 17:25:12.141677','취뽀취뽀',_binary '\0',NULL,22,8),(17,'2022-08-18 21:42:01.174488','2022-08-18 21:42:01.174488','어떤 방식으로 면접스터디가 진행되는지 여쭤볼 수 있을까요?',_binary '\0',NULL,27,6),(18,'2022-08-18 21:42:52.800012','2022-08-18 21:42:52.800012','주 2회는 기술 면접을 대비하고, 1회는 인성 면접을 준비하려고 합니다.',_binary '\0',17,27,4),(19,'2022-08-18 23:05:53.501506','2022-08-18 23:05:53.501506','안녕하세요! 면접스터디는 언제부터 시작하나요?',_binary '\0',NULL,30,5),(20,'2022-08-18 23:06:17.733899','2022-08-18 23:06:17.733899','아 그리고 몇 시에 시작하는지 알려주시면 감사합니다~!!',_binary '\0',19,30,5),(21,'2022-08-18 23:11:33.918481','2022-08-18 23:11:33.918481','몇시부터 진행이 되나요?',_binary '\0',NULL,1,6),(22,'2022-08-18 23:48:12.801882','2022-08-18 23:48:12.801882','몇시부터 몇시까지 스터디를 진행하는지 여쭤보고 싶습니다!',_binary '\0',NULL,17,6),(23,'2022-08-19 00:54:54.666101','2022-08-19 00:54:54.666101','안녕하세요 스터디 진행 방식은 어떻게 되나요?',_binary '\0',NULL,33,10);
/*!40000 ALTER TABLE `inquiries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:05:18
