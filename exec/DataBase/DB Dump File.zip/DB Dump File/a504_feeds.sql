-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7a504.p.ssafy.io    Database: a504
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feeds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `contents` varchar(200) NOT NULL,
  `is_deleted` bit(1) NOT NULL,
  `parent_id` int DEFAULT '0',
  `study_id` int NOT NULL,
  `member_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkpnydpgu005tyyvqq7kj308qx` (`parent_id`),
  KEY `FKorfrn53524sy26opri8eje4xn` (`study_id`),
  KEY `FK4itbxlri5qb3cymon3tlqhb3h` (`member_id`),
  CONSTRAINT `FK4itbxlri5qb3cymon3tlqhb3h` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`),
  CONSTRAINT `FKkpnydpgu005tyyvqq7kj308qx` FOREIGN KEY (`parent_id`) REFERENCES `feeds` (`id`),
  CONSTRAINT `FKorfrn53524sy26opri8eje4xn` FOREIGN KEY (`study_id`) REFERENCES `studies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` VALUES (1,'2022-08-18 14:21:37.693495','2022-08-18 14:21:37.693495','asf',_binary '\0',NULL,5,6),(2,'2022-08-18 14:21:39.946345','2022-08-18 14:21:39.946345','dafsd',_binary '\0',1,5,6),(3,'2022-08-18 15:06:46.107419','2022-08-18 15:06:46.107419','야호~',_binary '\0',NULL,14,11),(4,'2022-08-18 15:16:32.824206','2022-08-18 15:17:39.068856','ㅇㅇㄹㄴㅇ',_binary '\0',NULL,7,6),(5,'2022-08-18 15:16:35.515198','2022-08-18 15:16:35.515198','ㅇㅇㅇ',_binary '\0',4,7,6),(6,'2022-08-18 15:53:16.061423','2022-08-18 15:53:16.061423','저 이번주는 스터디가 어려울 것 같습니다. 혹시 다음주부터 시작하는 것은 어떤가요?',_binary '\0',NULL,9,6),(7,'2022-08-18 23:06:12.968185','2022-08-18 23:06:12.968185','모두 다음주 목요일 9시에 시간 괜찮으신가요?',_binary '\0',NULL,30,6),(8,'2022-08-18 23:06:26.309040','2022-08-19 00:14:01.911054','넵~ 괜찮습니다!',_binary '',7,30,4),(9,'2022-08-18 23:06:31.113449','2022-08-18 23:06:31.113449','넵! 좋습니다!!',_binary '\0',7,30,5),(10,'2022-08-18 23:06:31.738708','2022-08-18 23:06:31.738708','네 좋습니다~',_binary '\0',7,30,10),(11,'2022-08-18 23:54:00.152932','2022-08-18 23:54:00.152932','스터디 참여하신 분들은 여기에 가능한 시간대 댓글로 달아주세요!',_binary '\0',NULL,32,6),(12,'2022-08-19 00:43:34.810348','2022-08-19 00:43:34.810348','스터디 참여하신 분들은 아래 댓글에 가능하신 시간대를 공유해주세요!',_binary '\0',NULL,33,6),(13,'2022-08-19 00:44:16.503941','2022-08-19 00:44:16.503941','저는 평일 오후 전부 가능합니다.',_binary '\0',12,33,4),(14,'2022-08-19 00:45:16.160046','2022-08-19 00:45:16.160046','저는 오전만 아니면 다 좋습니다!',_binary '\0',12,33,5);
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:05:19
